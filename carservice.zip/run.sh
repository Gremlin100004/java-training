#!/bin/bash

java -jar carservice.jar

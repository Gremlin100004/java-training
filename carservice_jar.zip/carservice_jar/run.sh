#!/bin/bash

sudo java -jar carservice.jar
